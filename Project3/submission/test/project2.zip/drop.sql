Drop table if exists Items;
Drop table if exists Bids;
Drop table if exists Bidders;
Drop table if exists Sellers;
Drop table if exists Categories;
