In our design, we created inverted indexes on the ItemName, Categories, Description and the combination of them which named as Content and was set as default field.

This example contains a simple utility class to simplify opening database
connections in Java applications, such as the one you will write to build
your Lucene index. 

To build and run the sample code, use the "run" ant target inside
the directory with build.xml by typing "ant run".
